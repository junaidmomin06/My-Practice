# SQL-for-Data-Analytics
SQL tutorial inside a Jupyter Notebook
